package com.scit.c3.service;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.scit.c3.dao.RatingDAO;
import com.scit.c3.vo.RatingVO;

@Service
public class RatingService {
	
	@Autowired
	private RatingDAO dao;
	
	@Autowired
	private HttpSession session;
	
	public ArrayList<RatingVO> list(){
		return dao.list();
	}
	
	public String write(RatingVO rating) {
		
		// 전달받은 제목, 내용 데이터에 글쓴이의 아이디 값(세션 스코프에서)을 추가
		// 글 쓰기 기능
		String loginId = (String)session.getAttribute("loginId");
		rating.setMember_id(loginId);
		
		int cnt = dao.write(rating);
		// 글 쓰기 성공 -> 글 목록 , 실패 -> 글 작성 폼
		String path ="";
		
		if(cnt > 0) {
			path = "redirect:/rating/listForm";
		} else {
			path = "redirect:/rating/writeForm";
		}
		
		return path;
	}
	
	public String delete(RatingVO rating) {
		String path = "";
		
		String loginId = (String)session.getAttribute("loginId");
		rating.setMember_id(loginId);
		
		int cnt = dao.delete(rating);
		
		if(cnt > 0) {
			// 삭제 성공 -> 목록
			path = "redirect:/rating/listForm";
		} else {
			// 삭제 실패 -> 상세페이지
			path = "redirect:/rating/detail?board_no"+rating.getRating_num();
		}
		return path;
	}
	
	public RatingVO detail(int rating_num) {
		return dao.detail(rating_num);
	}
	
	public RatingVO selectOne(int rating_num) {
		return dao.selectOne(rating_num);
	}
	
	public String update(RatingVO rating) {
		String loginId = (String)session.getAttribute("loginId");
		rating.setMember_id(loginId);
		
		int cnt = dao.update(rating);
		String path="";
		
		
		if(cnt > 0) {
			path = "redirect:/rating/listForm";
		} else {
			path = "redirect:/rating/updateForm?rating_num="+rating.getRating_num();
		}
		return path;
	}
	
	
}
