package com.scit.c3.service;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.scit.c3.vo.MemberVO;
import com.scit.c3.dao.MemberDAO;

@Service
public class MemberService {
	
	@Autowired
	private MemberDAO dao;
	@Autowired
	private HttpSession session;
	
	public String joinForm() {
		return "redirect:/member/joinForm";
	}
	
	public String join(MemberVO member) {
		
		int cnt = dao.join(member);
		String path = ""; 
		
		if(cnt > 0) {
			path = "redirect:/";
		} else {
			path = "redirect:/member/joinForm";
		}
		return path;
	}
	
	public String login(MemberVO member) {
		
		MemberVO result = dao.search(member.getMember_id());
		
		String path="";
		
		if(result == null) {
			path = "redirect:/member/loginForm";
		} else {
			if(member.getMember_pw().equals(result.getMember_pw())) {
				session.setAttribute("loginId", result.getMember_id());
				session.setAttribute("loginPw", result.getMember_pw());
				session.setAttribute("loginNm", result.getMember_nm());
				path = "redirect:/";
			} else {
				// 비밀번호를 잘못 입력한 경우
				path = "redirect:/member/loginForm";
			}
		}
		
		return path;
	}
	
	public void logout() {
		session.removeAttribute("loginId");
		session.removeAttribute("loginPw");
		session.removeAttribute("loginNm");
	}

}
