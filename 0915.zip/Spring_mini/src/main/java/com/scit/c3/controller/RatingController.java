package com.scit.c3.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import com.scit.c3.service.RatingService;
import com.scit.c3.vo.RatingVO;

@Controller
public class RatingController {

	@Autowired
	private RatingService service;
	
	@RequestMapping(value="/rating/listForm", method = RequestMethod.GET)
	public String listForm(Model model) {
		
		ArrayList<RatingVO> result = service.list();
		
		model.addAttribute("result", result);
		
		return "rating/listForm";
	}
	
	@RequestMapping(value="/rating/write", method = RequestMethod.POST)
	public String write(RatingVO rating) {
		String path = service.write(rating);
		
		return path;
	}
	
	@RequestMapping(value="/rating/writeForm", method = RequestMethod.GET)
	public String writeForm() {
		
		return "rating/writeForm";
	}
	
	@RequestMapping(value="/rating/detail", method = RequestMethod.GET)
	public String detail(int rating_num, Model model) {
		RatingVO rating = service.detail(rating_num);
		model.addAttribute("rating", rating);
		
		return "rating/detail";
	}
	
	@RequestMapping(value="/rating/delete", method = RequestMethod.GET)
	public String delete(RatingVO rating) {
		
		return service.delete(rating);
	}
	
	@RequestMapping(value="/rating/updateForm", method = RequestMethod.GET)
	public String updateForm(int rating_num, Model model) {
		RatingVO rating = service.selectOne(rating_num);
		model.addAttribute("rating", rating);
		
		return "rating/updateForm";
	}
	
	@RequestMapping(value="/rating/update", method = RequestMethod.POST)
	public String update(RatingVO rating) {
		
		return service.update(rating);
	}
	
}
