package com.scit.c3.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.scit.c3.vo.MemberVO;
import com.scit.c3.service.MemberService;

@Controller
public class MemberController {
	
	@Autowired
	private MemberService service;
	
	@RequestMapping(value="/member/joinForm", method = RequestMethod.GET)
	public String joinForm() {
		return "member/joinForm";
	}
	
	@RequestMapping(value="/member/join", method = RequestMethod.POST)
	public String join(MemberVO member) {
		String path = service.join(member);
		return path;
	}
	
	@RequestMapping(value="/member/loginForm", method = RequestMethod.GET)
	public String loginForm() {
		return "/member/loginForm";
	}
	
	@RequestMapping(value="/member/login", method = RequestMethod.POST)
	public String login(MemberVO member) {
		String path = service.login(member);
		return path;
	}
	
	@RequestMapping(value="/member/logout", method = RequestMethod.GET)
	public String logout() {
		service.logout();
		return "redirect:/";
	}
	
}
