package com.scit.c3.dao;

import java.util.ArrayList;

import com.scit.c3.vo.RatingVO;

public interface RatingMapper {

	public ArrayList<RatingVO> list();

	public int write(RatingVO rating);

	public int delete(RatingVO rating);

	public RatingVO detail(int rating_num);

	public int update(RatingVO rating);

}
