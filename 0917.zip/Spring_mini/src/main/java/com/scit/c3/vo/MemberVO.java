package com.scit.c3.vo;

import lombok.Data;

@Data
public class MemberVO {
	private String member_id;
	private String member_pw;
	private String member_nm;
	private String member_indate;
	private int member_pt;
}
