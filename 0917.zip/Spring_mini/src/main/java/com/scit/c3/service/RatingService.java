package com.scit.c3.service;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import com.scit.c3.dao.RatingDAO;
import com.scit.c3.vo.RatingVO;
import com.scit.c3.util.FileService;

@Service
public class RatingService {
	
	@Autowired
	private RatingDAO dao;
	@Autowired
	private HttpSession session;
	@Autowired
	private HttpServletResponse response;
	
	private static final String UPLOAD_PATH = "/ratingFiles";
	
	public ArrayList<RatingVO> list(String searchText, int startRecord, int countPerPage){
		return dao.list(searchText, startRecord, countPerPage);
	}
	
	public String write(RatingVO rating, MultipartFile upload) {
		
		if(!upload.isEmpty()) {
			String original = upload.getOriginalFilename();
			String saved = FileService.saveFile(upload, UPLOAD_PATH);
			
			rating.setRating_original(original);
			rating.setRating_saved(saved);
		}
		
		// 전달받은 제목, 내용 데이터에 글쓴이의 아이디 값(세션 스코프에서)을 추가
		// 글 쓰기 기능
		String loginId = (String)session.getAttribute("loginId");
		rating.setMember_id(loginId);
		
		int cnt = dao.write(rating);
		// 글 쓰기 성공 -> 글 목록 , 실패 -> 글 작성 폼
		String path ="";
		
		if(cnt > 0) {
			path = "redirect:/rating/listForm";
		} else {
			path = "redirect:/rating/writeForm";
		}
		
		return path;
	}
	
	public String delete(RatingVO rating) {
		String path = "";
		
		String loginId = (String)session.getAttribute("loginId");
		rating.setMember_id(loginId);
		
		int cnt = dao.delete(rating);
		
		if(cnt > 0) {
			// 삭제 성공 -> 목록
			path = "redirect:/rating/listForm";
		} else {
			// 삭제 실패 -> 상세페이지
			path = "redirect:/rating/detail?board_no"+rating.getRating_num();
		}
		return path;
	}
	
	public RatingVO detail(int rating_num) {
		return dao.detail(rating_num);
	}
	
	public RatingVO selectOne(int rating_num) {
		return dao.selectOne(rating_num);
	}
	
	public String update(RatingVO rating) {
		String loginId = (String)session.getAttribute("loginId");
		rating.setMember_id(loginId);
		
		int cnt = dao.update(rating);
		String path="";
		
		
		if(cnt > 0) {
			path = "redirect:/rating/listForm";
		} else {
			path = "redirect:/rating/updateForm?rating_num="+rating.getRating_num();
		}
		return path;
	}
	
	public String recommend(RatingVO rating) {
		String path = "";
		int cnt = dao.recommend(rating);
		
		if(cnt > 0) {
			path = "redirect:/rating/listForm";
		} else {
			path = "redirect:/rating/detail?board_no"+rating.getRating_num();
		}
		
		return path;
	}
	
	public int totalRecord() {
		return dao.totalRecord();
	}
	
	public void download(int rating_num) {
		RatingVO rating = dao.selectOne(rating_num);
	
		String originalFile = rating.getRating_original();
		
		try {
			// 응답할때 파일을 같이 전송하고, 그 파일은 지정된 파일명으로 다운로드를 하는 설정
			response.setHeader("Content-Disposition", " attachment;filename="+ URLEncoder.encode(originalFile, "UTF-8"));
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		//저장된 파일 경로
		String fullPath = UPLOAD_PATH + "/" + rating.getRating_saved();
		
		//서버의 파일을 읽을 입력 스트림과 클라이언트에게 전달할 출력스트림
		FileInputStream filein = null;
		ServletOutputStream fileout = null;
				
		try {
			filein = new FileInputStream(fullPath);
			fileout = response.getOutputStream();
					
			//Spring의 파일 관련 유틸
			FileCopyUtils.copy(filein, fileout);
					
			filein.close();
			fileout.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	
	
}
