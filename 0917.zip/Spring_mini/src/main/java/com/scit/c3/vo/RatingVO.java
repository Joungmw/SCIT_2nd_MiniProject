package com.scit.c3.vo;

import lombok.Data;

@Data
public class RatingVO {
	private int rating_num;
	private String rating_shop;
	private String rating_content;
	private String member_id;
	private int rating_pt;
	private String rating_original;
	private String rating_saved;
}
