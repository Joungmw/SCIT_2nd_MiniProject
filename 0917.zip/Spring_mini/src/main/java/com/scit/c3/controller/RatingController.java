package com.scit.c3.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.scit.c3.service.RatingService;
import com.scit.c3.vo.RatingVO;
import com.scit.c3.util.PageNavigator;

@Controller
public class RatingController {

	@Autowired
	private RatingService service;
	
	private final int countPerPage = 3;
	private final int pagePerGroup = 3;
	
	@RequestMapping(value="/rating/listForm", method = RequestMethod.GET)
	public String listForm(Model model
			, @RequestParam(name = "searchText", defaultValue="") String searchText
			, @RequestParam(name = "currentPage", defaultValue="1") int currentPage) {
		
		int totalRecordsCount = service.totalRecord();
		
		PageNavigator navi = new PageNavigator(countPerPage, pagePerGroup, currentPage, totalRecordsCount);
		
		ArrayList<RatingVO> result = service.list(searchText, navi.getStartRecord(), navi.getCountPerPage());
		
		model.addAttribute("result", result);
		model.addAttribute("searchText", searchText);
		model.addAttribute("navi", navi);
		
		return "rating/listForm";
	}
	
	@RequestMapping(value="/rating/write", method = RequestMethod.POST)
	public String write(RatingVO rating, MultipartFile upload) {
		String path = service.write(rating, upload);
		
		return path;
	}
	
	@RequestMapping(value="/rating/writeForm", method = RequestMethod.GET)
	public String writeForm() {
		
		return "rating/writeForm";
	}
	
	@RequestMapping(value="/rating/detail", method = RequestMethod.GET)
	public String detail(int rating_num, Model model) {
		RatingVO rating = service.detail(rating_num);
		model.addAttribute("rating", rating);
		
		return "rating/detail";
	}
	
	@RequestMapping(value="/rating/delete", method = RequestMethod.GET)
	public String delete(RatingVO rating) {
		
		return service.delete(rating);
	}
	
	@RequestMapping(value="/rating/updateForm", method = RequestMethod.GET)
	public String updateForm(int rating_num, Model model) {
		RatingVO rating = service.selectOne(rating_num);
		model.addAttribute("rating", rating);
		
		return "rating/updateForm";
	}
	
	@RequestMapping(value="/rating/update", method = RequestMethod.POST)
	public String update(RatingVO rating) {
		
		return service.update(rating);
	}
	
	@RequestMapping(value="/rating/recommend", method = RequestMethod.GET)
	public String recommend(RatingVO rating) {
		
		return service.recommend(rating);
	}
	
	@RequestMapping(value="/rating/download", method = RequestMethod.GET)
	public String download(int rating_num) {
		service.download(rating_num);
		
		return null;
	}
	
}
