package com.scit.c3.dao;

import com.scit.c3.vo.MemberVO;

public interface MemberMapper {

	int join(MemberVO member);

	MemberVO search(String id);

	int plus_Pt(MemberVO member);

}
