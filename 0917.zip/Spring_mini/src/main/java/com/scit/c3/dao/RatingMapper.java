package com.scit.c3.dao;

import java.util.ArrayList;

import org.apache.ibatis.session.RowBounds;

import com.scit.c3.vo.RatingVO;

public interface RatingMapper {

	public ArrayList<RatingVO> list(String searchText, RowBounds rb);

	public int write(RatingVO rating);

	public int delete(RatingVO rating);

	public RatingVO detail(int rating_num);

	public int update(RatingVO rating);

	public int recommend(RatingVO rating);

	public int totalRecord();

}
