package com.scit.c3.dao;

import java.util.ArrayList;

import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.scit.c3.dao.RatingMapper;
import com.scit.c3.vo.RatingVO;

@Repository
public class RatingDAO {
	
	@Autowired
	private SqlSession session;
	
	public ArrayList<RatingVO> list(String searchText, int startRecord, int countPerPage){
		ArrayList<RatingVO> result = null;
		try {
			RatingMapper mapper = session.getMapper(RatingMapper.class);
			
			RowBounds rb = new RowBounds(startRecord, countPerPage);
			
			result = mapper.list(searchText, rb);		
		}catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public int write(RatingVO rating) {	
		int cnt = 0;
		try {
			RatingMapper mapper = session.getMapper(RatingMapper.class);
			cnt = mapper.write(rating);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return cnt;
	}
	
	public int delete(RatingVO rating) {
		int cnt = 0;
		
		try {
			RatingMapper mapper = session.getMapper(RatingMapper.class); 
			cnt = mapper.delete(rating);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return cnt;
	}
	
	public RatingVO detail(int rating_num) {
		RatingVO result = null;
		
		try {
			RatingMapper mapper = session.getMapper(RatingMapper.class); 
			result = mapper.detail(rating_num);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public int update(RatingVO rating) {
		int cnt = 0;
		try {
			RatingMapper mapper = session.getMapper(RatingMapper.class);
			cnt = mapper.update(rating);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return cnt;
	}
	
	public RatingVO selectOne(int rating_num) {
		RatingVO rating = null;
		
		try {
			RatingMapper mapper = session.getMapper(RatingMapper.class);
			rating = mapper.detail(rating_num);
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return rating;
	}
	
	public int recommend(RatingVO rating) {
		int cnt = 0;
		try {
			RatingMapper mapper = session.getMapper(RatingMapper.class); 
			cnt = mapper.recommend(rating);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return cnt;
	}
	
	public int totalRecord() {
		int totalRecordsCount = 0;
		try {
			RatingMapper mapper = session.getMapper(RatingMapper.class);
			totalRecordsCount = mapper.totalRecord();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return totalRecordsCount;
	}

	
}
